// nav
let menu = document.querySelector('#menu-icon');
let nav = document.querySelector('.nav');
 
menu.onclick = () => {
    nav.classList.toggle('active');
}
 
window.onscroll = () => {
    nav.classList.remove('active');
}
// sötét- világos mód
let sotet = document.querySelector('#sotet');
 
sotet.onclick = () => {
    if(sotet.classList.contains('bx-moon')){
        sotet.classList.replace('bx-moon','bx-sun');
        document.body.classList.add('active');
    }else{
        sotet.classList.replace('bx-sun','bx-moon');
        document.body.classList.remove('active');
    }
}
 
// Scroll Reveal
const sr = ScrollReveal ({
    origin: 'top',
    distance: '40px',
    duration: 2000,
    reset: true
});
 
 
sr.reveal(`.home-text, .home-img,
            .about-img, .about-text,
            .box, .s-box,
            .btn, .connect-text,
            .contact-box`, {
    interval: 200
})

function kosarba(boxid){
    var hatterek = document.getElementsByClassName("box");
    hatterek[boxid].style.border = "3px solid #ffb411";
}

function BorderTorles(){
    var hatterek = document.getElementsByClassName("box");
    hatterek[0].style.border = "none";
    hatterek[1].style.border = "none";
    hatterek[2].style.border = "none";
}

function doboz(boxid){
    var hatterek = document.getElementsByClassName("box");
    hatterek[boxid].style.doboz = "2px 2px 5px 2px gray";
}

function dobozTorles(boxid){
    var hatterek = document.getElementsByClassName("box");
    hatterek[boxid].style.doboz = "none";
}